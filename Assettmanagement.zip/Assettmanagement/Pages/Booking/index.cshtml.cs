using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Assettmanagement.Pages.Booking
{
    public class BookingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
